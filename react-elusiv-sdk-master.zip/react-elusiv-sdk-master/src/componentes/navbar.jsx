import React from 'react'

const Navbar = () => {
  return (
    <div class="container">
        <div class="row">
            <div class="col">
            <a href="/"><button>Home </button>  </a>
            </div>
            <div class="col">
            <a href="/tx"><button>Tx </button> </a>
            </div>
            
        </div>
    </div>
  )
}

export default Navbar;